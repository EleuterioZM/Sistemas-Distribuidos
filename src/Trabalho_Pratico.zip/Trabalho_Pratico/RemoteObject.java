package Trabalho_Pratico;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class RemoteObject extends UnicastRemoteObject implements RemoteInterface {
    private List<EquipamentoApoio> listaRecursos = new ArrayList<>();
    private Map<Integer, ClienteCallback> callbacks = new HashMap<>();

    public RemoteObject() throws RemoteException {
        // Construtor padrão
    }

    @Override
    public void inserirRecurso(EquipamentoApoio recurso) throws RemoteException {
        listaRecursos.add(recurso);
    }

    @Override
    public List<EquipamentoApoio> consultarRecursos(String descricao) throws RemoteException {
        return listaRecursos.stream()
                .filter(r -> r.getDescricao().contains(descricao))
                .collect(Collectors.toList());
    }

    @Override
    public String requisitarRecurso(int id, ClienteCallback callback) throws RemoteException {
        EquipamentoApoio recurso = getRecursoById(id);
        if (recurso != null) {
            if (recurso.isDisponivel()) {
                recurso.setRequisitado(true);
                callbacks.put(id, callback);

                return "Recurso requisitado com sucesso";
            } else {

                return "Recurso reservado";

            }
        } else {
           
            return "Recurso não encontrado";
        }
    }

    @Override
    public String devolverRecurso(int id) throws RemoteException {
        EquipamentoApoio recurso = getRecursoById(id);
        if (recurso != null) {
            if (recurso.isRequisitado()) {
                recurso.setDisponivel(true);
                recurso.setRequisitado(false);

                return "Recurso devolvido com sucesso. Agora está disponível novamente.";
            } else {
                return "Este recurso não foi requisitado e não pode ser devolvido.";
            }
        } else {
            return "Recurso não encontrado.";
        }
    }

    @Override
    public List<EquipamentoApoio> listarRecursos() throws RemoteException {
        return listaRecursos.stream()
                .filter(EquipamentoApoio::isDisponivel)
                .collect(Collectors.toList());
    }

    private EquipamentoApoio getRecursoById(int id) {
        return listaRecursos.stream()
                .filter(r -> r.getId() == id)
                .findFirst()
                .orElse(null);
    }
}
